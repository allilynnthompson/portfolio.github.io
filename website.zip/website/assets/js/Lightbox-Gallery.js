window.addEventListener('load', function () {
    baguetteBox.run('.gallery', {
		animation: 'slideIn',
		noScrollbars: false
	});
});
